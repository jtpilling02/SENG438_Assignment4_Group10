package org.jfree.data.test.datautilities;

import static org.junit.Assert.*;

import org.jfree.data.DataUtilities; 
import org.jfree.data.Values2D;
import org.jmock.Expectations; 
import org.junit.*;
import org.jmock.Mockery;

public class DataUtilitiesCalculateRowTotal {
	static Mockery mockingContext; // declaring mockery class object
	static Values2D values; // declaring values2d interface to be mocked

    @Before
    public void setUp() throws Exception { // initializes the mockery for Values2D
    	mockingContext = new Mockery();
    	values = mockingContext.mock(Values2D.class);
    }

    @Test
    public void fourcolumn_calculateRowTotal() { // testing to ensure a table of 4 columns returns the correct row total
    	mockingContext.checking(new Expectations() {
            {
                one(values).getColumnCount(); // utilizes mockery to hard code a table to be used
                will(returnValue(4));
                
                one(values).getValue(0, 0);
                will(returnValue(2));
                one(values).getValue(0, 1);
                will(returnValue(3));
                one(values).getValue(0, 2);
                will(returnValue(0));
                one(values).getValue(0, 3);
                will(returnValue(2));  // row values are : 2, 3, 0, 2
            }
        });
    	
    	assertEquals("the result should be true, indicating the sum of row 1 (2+3+0+2) in table 1 is 7", 7,
    			DataUtilities.calculateRowTotal(values, 0), .000000001d); // expected: row sum =  7
    }
  
    @Test
    public void onecolumn_calculateRowTotal() { // testing to ensure a table of a single columns returns the correct row total
    	mockingContext.checking(new Expectations() {
            {
                one(values).getColumnCount(); // utilizes mockery to hard code a table to be used
                will(returnValue(1));
                
                one(values).getValue(0, 0);
                will(returnValue(2));   // row values are : 2
            }
        });
    	
    	assertEquals("the result should be true, indicating the sum of row 1 (2) in table 1 is 2", 2,
    			DataUtilities.calculateRowTotal(values, 0), .000000001d); // expected: row sum =  2
    }
    
//    @Test
//    public void onecolumn_calculateRowTotalwithNull() { // testing to ensure a table of a single columns returns the correct row total
//    	mockingContext.checking(new Expectations() {
//            {
//                one(values).getColumnCount(); // utilizes mockery to hard code a table to be used
//                will(returnValue(0));
//                
//                one(values).getValue(0, 0);
//                will(returnValue(2));   // row values are : 2
//            }
//        });
//    	
//    	assertNotEquals("the result should be true, indicating the sum of row 1 (2) in table 1 is 2", 2,
//    			DataUtilities.calculateRowTotal(values, 0), .000000001d); // expected: row sum =  2
//    }
    
    @Test
    public void onecolumn_calculateRowTotalWithValidCol() { // testing to ensure a table of a single columns returns the correct row total
    	mockingContext.checking(new Expectations() {
            {
                one(values).getColumnCount(); // utilizes mockery to hard code a table to be used
                will(returnValue(1));
                
                one(values).getValue(0, 0);
                will(returnValue(2));   // row values are : 2
            }
        });
    	int[] col = {0};
    	assertEquals("the result should be true, indicating the sum of row 1 (2) in table 1 is 2", 2,
    			DataUtilities.calculateRowTotal(values, 0, col), .000000001d); // expected: row sum =  2
    }
    
    @Ignore		//This test is ignored due to the expected exception that is thrown.
    @Test(expected = IllegalStateException.class)
	public void calculateColumnTotalWithInvalidParameter() throws IllegalStateException {

		mockingContext = new Mockery();
		values = mockingContext.mock(Values2D.class);
		mockingContext.checking(new Expectations() {
			{
				one(values).getRowCount();
				will(returnValue(null));
				one(values).getColumnCount();
				will(returnValue(null));
			}
		});
		assertEquals(0, DataUtilities.calculateColumnTotal(values, 0), .000000001d);

	}

    @After
    public void tearDown() throws Exception {
    }
}
