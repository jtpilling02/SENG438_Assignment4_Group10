package org.jfree.data.test.datautilities;

import static org.junit.Assert.*;

import org.jfree.data.DataUtilities;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

/**
 * @author Luis Miranda
 *
 */
public class DataUtilitiesCreateNumberArray extends DataUtilities {
	// Instantiate global variables
	double[] input1DArray;
	double[] null1DArray;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		input1DArray = new double[] {-11231.234E23, 12331.4123E2, 2.0, 9.0, 5.0};
	}
	

	/**
	 * Testing null values and if the method throws the right exception
	 */
    @Ignore		//This test is ignored due to the expected exception that is thrown.
	@Test(expected = IllegalArgumentException.class)
	public void createNumberArrayTestNull() {
		try {
			DataUtilities.createNumberArray(null);
			fail();
		} catch (IllegalArgumentException ex){
			assertEquals("Null 'data' argument.", ex.getMessage());
		}
	}
	
	/**
	 * checking if the Number Array had been instantiated properly
	 * there seems to be a bug with the index
	 */
	@Test
	public void testcreateNumberArray()
	{
		Number[] actual = DataUtilities.createNumberArray(input1DArray);
		Number[] expected = new Number[]{-11231.234E23, 12331.4123E2, 2.0, 9.0, 5.0};
		
		assertEquals("Array contents must be equal.", input1DArray[0],
				actual[0].doubleValue(), 0.0000001);
		assertEquals("Array contents must be equal.", input1DArray[1],
				actual[1].doubleValue(), 0.0000001);
		assertEquals("Array contents must be equal.", input1DArray[2],
				actual[2].doubleValue(), 0.0000001);
	}
	
	/**
	 * Bug in the method as there should be an element at actual if all the 
	 * elements have been converted but there the method throws
	 * a NullPointerException
	 */
    @Ignore		//This test is ignored due to the expected exception that is thrown.
	@Test(expected = NullPointerException.class)
	public void testcreateNumberArrayIndex()
	{
		Number[] actual = DataUtilities.createNumberArray(input1DArray);
		Number[] expected = new Number[]{-11231.234E23, 12331.4123E2, 2.0, 9.0, 5.0};
		
		
		assertEquals("Array contents must be equal.", input1DArray[0],
				actual[0].doubleValue(), 0.0000001);
		assertEquals("Array contents must be equal.", input1DArray[1],
				actual[1].doubleValue(), 0.0000001);
		assertEquals("Array contents must be equal.", input1DArray[4],
				actual[4].doubleValue(), 0.0000001);
	}
	
	/**
	 * Tests if the array length is correct as the element at the end is left off
	 * by the program
	 */
	@Test
	public void testArrayLength()
	{
		Number[] actual = DataUtilities.createNumberArray(input1DArray);
		assertEquals("Array Length must be the same", input1DArray.length, actual.length);
	}
	
	@After
	public void tearDown() throws Exception {
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}








}
