package org.jfree.data.test.range;

import static org.junit.Assert.*; import org.jfree.data.Range; import org.junit.*;

public class RangeTest {
	/**
	 * A over-arching test class for the Range class, for all methods that were
	 * previously not tested in the past lab.
	 */
    private Range exampleRange1;
    private Range exampleRange2;
    private Range exampleRange3;
    private Range exampleRange4;
    private Range exampleRange5;
    private Range exampleRange6;
    private Range exampleRange7;
    private Range exampleRange8;
    private Range exampleRange9;
    @BeforeClass public static void setUpBeforeClass() throws Exception {
    }
    
    @Before
    public void setUp() throws Exception { 
    	exampleRange4 = new Range(-1, 1);
    	exampleRange5 = new Range(5, 10);
        exampleRange6 = new Range(0.0/0.0, 5);
    	exampleRange7 = new Range(5, 0.0/0.0);
    	exampleRange8 = new Range(0.0/0.0, 0.0/0.0);
    	exampleRange9 = new Range(-2,3);
    }
    
    /**
     * Test methods for the combines and combinesIgnoringNaN methods.
     */
    @Test
    public void combinesTest_Valid() {
    	exampleRange1 = new Range(0, 10);
    	exampleRange2 = new Range(-10, 5);
    	exampleRange3 = new Range(-10,10);
    	
    	assertEquals("Range Should be -10,10.",Range.combine(exampleRange1, exampleRange2),
    			exampleRange3);
    }
    
    @Test
    public void combinesTest_Null() {
    	exampleRange1 = null;
    	exampleRange2 = null;
    	exampleRange3 = null;
    	
    	assertEquals("Range Should be null.",Range.combine(exampleRange1, exampleRange2),
    			exampleRange3);
    }
    
    @Test
    public void combinesTest_NullRange2() {
    	exampleRange1 = new Range (10,12);
    	exampleRange2 = null;
    	exampleRange3 = new Range (10,12);
    	
    	assertEquals("Range Should be null.",Range.combine(exampleRange1, exampleRange2),
    			exampleRange3);
    }
    
    @Test
    public void combinesTest_NullRange1() {
    	exampleRange1 = null;
    	exampleRange2 = new Range (10, 12);
    	exampleRange3 = new Range (10, 12);
    	
    	assertEquals("Range Should be null.",Range.combine(exampleRange1, exampleRange2),
    			exampleRange3);
    }
    
    @Test
    public void combinesIgnoringNaNTest_Valid() {
    	exampleRange1 = new Range(0, 10);
    	exampleRange2 = new Range(-10, 5);
    	exampleRange3 = new Range(-10,10);
    	
    	assertEquals("Range Should be -10,10.",Range.combineIgnoringNaN(exampleRange1, exampleRange2),
    			exampleRange3);
    }
    
    @Test
    public void combinesIgnoringNaNTest_Null() {
    	exampleRange1 = null;
    	exampleRange2 = null;
    	exampleRange3 = null;
    	
    	assertEquals("Range Should be null.",Range.combineIgnoringNaN(exampleRange1, exampleRange2),
    			exampleRange3);
    }
    
    @Test
    public void combinesIgnoringNaNTest_NullRange1() {
    	exampleRange1 = null;
    	exampleRange2 = new Range (10, 12);
    	exampleRange3 = new Range (10, 12);
    	
    	assertEquals("Range Should be null.",Range.combineIgnoringNaN(exampleRange1, exampleRange2),
    			exampleRange3);
    }
    
    @Test
    public void combinesIgnoringNaNTest_NullRange2() {
    	exampleRange1 = new Range (10,12);
    	exampleRange2 = null;
    	exampleRange3 = new Range (10,12);
    	
    	assertEquals("Range Should be null.",Range.combineIgnoringNaN(exampleRange1, exampleRange2),
    			exampleRange3);
    }
    
    /**
     * Test methods for the expand and expandToInclude methods.
     */
    @Test
    public void expandTest_Valid() {
    	exampleRange1 = new Range(10,12);
    	exampleRange2 = new Range(6,20);
	
    	assertEquals("Range Should be 8,16.",Range.expand(exampleRange1, 2, 4), exampleRange2);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void expandTest_InValid() {
    	exampleRange1 = new Range(16,8);
    	exampleRange2 = new Range(14,12);
    }
    
    @Test
    public void expandToIncludeTest_Lower() {
    	exampleRange1 = new Range(10,12);
    	exampleRange2 = new Range(6,12);

    	assertEquals("Range Should be 6,12.",Range.expandToInclude(exampleRange1, 6),
    			exampleRange2);
    }
    
    @Test
    public void expandToIncludeTest_Upper() {
    	exampleRange1 = new Range(10,12);
    	exampleRange2 = new Range(10,16);

    	assertEquals("Range Should be 10,16.",Range.expandToInclude(exampleRange1, 16),
    			exampleRange2);
    }
    
    @Test
    public void expandToIncludeTest_EqualLower() {
    	exampleRange1 = new Range(10,12);
    	exampleRange2 = new Range(10,12);

    	assertEquals("Range Should be 10,12.",Range.expandToInclude(exampleRange1, 10),
    			exampleRange2);
    }
    
    @Test
    public void expandToIncludeTest_EqualUpper() {
    	exampleRange1 = new Range(10,12);
    	exampleRange2 = new Range(10,12);

    	assertEquals("Range Should be 10,12.",Range.expandToInclude(exampleRange1, 12),
    			exampleRange2);
    }
    
	/**
	 * Test methods for the equals method.
	 */
    @Test
    public void givenNormalRange_whenToString_thenReturnString() {
        assertTrue(exampleRange4.toString().equals("Range[-1.0,1.0]"));
    }
    
    @Test
    public void givenNormalRangeWithSameRange_whenEquals_thenReturnTrue() {
        assertTrue(exampleRange4.equals(exampleRange4));
    }
    
    @Test
    public void givenNormalRangeWithDifferentRange_whenEquals_thenReturnFalse() {
        assertFalse(exampleRange4.equals(exampleRange5));
    }
    
    @Test
    public void givenNormalRangeWithInvalidObject_whenEquals_thenReturnFalse() {
        assertFalse(exampleRange4.equals(1000));
    }
    
	
    @Test
    public void givenNormalRange_whenIsNaNRange_thenReturnFalse() {
        assertFalse(exampleRange4.isNaNRange());
    }
    
    /**
     * Test methods for the intersects method.
     */
    @Test
    public void givenNormalRangeWithValidDouble_whenIntersects_thenReturnTrue() {
        assertTrue(exampleRange4.intersects(0.0, 1.0));
    }
    
    @Test
    public void givenNormalRangeWithInvalidDouble_whenIntersects_thenReturnFalse() {
        assertFalse(exampleRange4.intersects(100.0, 101.0));
    }
    
    @Test
    public void givenNormalRangeWithValidRange_whenIntersects_thenReturnTrue() {
        assertTrue(exampleRange4.intersects(exampleRange4));
    }
    
    @Test
    public void givenNormalRangeWithInvalidRange_whenIntersects_thenReturnFalse() {
        assertFalse(exampleRange4.intersects(exampleRange5));
    }
    
    /**
     * Test method for hashCode method.
     */
//    @Test
//    public void givenNormalRange_whenHashCode_thenReturnString() {
//        assertTrue(exampleRange4.hashCode() > 0);
//    }
    
    
    /**
     * Test methods for isNaNRange method.
     */
	@Test
	public void givenNormalRangeFirstNaN_whenIsNaNRange_thenReturnFalse() {
	    assertFalse(exampleRange6.isNaNRange());
	}
	@Test
	public void givenNormalRangeSecondNaN_whenIsNaNRange_thenReturnFalse() {
	    assertFalse(exampleRange7.isNaNRange());
	}
	@Test
	public void givenNormalRangeBothNaN_whenIsNaNRange_thenReturnTrue() {
	    assertTrue(exampleRange8.isNaNRange());
	}
	
	/**
	 * Test methods for constrain method.
	 */
	@Test
    public void testConstrainInRange() { 	
    	assertEquals("value in range should print out the number", -1,
   		       exampleRange9.constrain(-1), .000000001d);
    }
    
    @Test
    public void testConstrainGreaterThanUpper() { 	
    	assertEquals("value in range should print out the number", 3,
    			exampleRange9.constrain(4), .000000001d); 
    }
    
    @Test
    public void testConstrainLessThanLower() { 	
    	assertEquals("value in range should print out the number", -2,
    			exampleRange9.constrain(-4), .000000001d); 
    }
    
    /**
     * Test methods for shift methods.
     */
    @Test
    public void shift_TestOverZeroFlag() {
    	exampleRange1 = new Range(-4,12);
    	exampleRange2 = new Range(2,18);
    	
    	assertEquals("Range Should be 2,18.",Range.shift(exampleRange1, 6, true),
    			exampleRange2);
    }
    
    @Test
    public void shift_TestNoZeroCrossingPos() {
    	exampleRange1 = new Range(-4,12);
    	exampleRange2 = new Range(0, 18);
    	
    	assertEquals("Range Should be 0,18.",Range.shift(exampleRange1, 6, false),
    			exampleRange2);
    }
    
    @Test
    public void shift_TestNoZeroCrossingNeg() {
    	exampleRange1 = new Range(-12,-4);
    	exampleRange2 = new Range(-6, 0);
    	
    	assertEquals("Range Should be 0,18.",Range.shift(exampleRange1, 6, false),
    			exampleRange2);
    }
    
    @Test
    public void shift_TestNotOverZeroFlag() {
    	exampleRange1 = new Range(-4,12);
    	exampleRange2 = new Range(0, 18);
    	
    	assertEquals("Range Should be 0,18.",Range.shift(exampleRange1, 6, false),
    			exampleRange2);
    }
    
    
    /**
     * Test methods for scale method.
     */
    @Test
    public void scale_PositiveTest() {
    	exampleRange1 = new Range(1,10);
    	exampleRange2 = new Range(4, 40);
    	
    	assertEquals("Range Should be 4,40.",Range.scale(exampleRange1, 4),
    			exampleRange2);
    }
    
    @Ignore		//This test is ignored due to the expected exception that is thrown.
    @Test(expected = IllegalArgumentException.class)
    public void scale_NegativeTest() {
    	try {
        	exampleRange1 = new Range(1,10);
        	exampleRange2 = new Range(-4,-40);
        	
        	assertEquals("Range Should be -4,-40.",Range.scale(exampleRange1, -4),
        			exampleRange2);
    	} catch(IllegalArgumentException ex) {
			assertEquals("Negative Scale", ex.getMessage());
    	}
    }
    

    
    @After
    public void tearDown() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }
}