package org.jfree.data.test.range;
import static org.junit.Assert.*; import org.jfree.data.Range; import org.junit.*;

public class RangeGetLength {
    private Range exampleRange1;
    private Range exampleRange2;
    private Range exampleRange3;
    private Range exampleRange4;

    @Before
    public void setUp() throws Exception { // initializing all the ranges used for testing
    	exampleRange1 = new Range(-2147483647, 0);
    	exampleRange2 = new Range(0, 2147483647);
    	exampleRange3 = new Range(0, 0);
    	exampleRange4 = new Range (-2, 3);
    }
    
    @Test
    public void getlength_minrange() { // testing to ensure a range from min int to 0 has the length of max int
        assertEquals("the result should be true, indicating the range (-2147483647, 0) has length of 2147483647", 2147483647,
       exampleRange1.getLength(), .000000001d); // expected: has length of max integer
    }
    
    @Test
    public void getlength_maxrange() { // testing to ensure a range from 0 to max int has the length of max int
        assertEquals("the result should be true, indicating the range (0, 2147483647) has length of 2147483647", 2147483647,
       exampleRange2.getLength(), .000000001d); // expected: has length of max integer
    }
    
    @Test
    public void getlength_zero() { // testing to ensure an empty range has a length of zero
        assertEquals("the result should be true, indicating the range (0, 0) has length of 0", 0,
       exampleRange3.getLength(), .000000001d); // expected: length is 0
    }
    
    @Test
    public void getlength_negtopos() { // testing to ensure correct calculations are made for ranges that extend below zero and above zero
        assertEquals("the result should be true, indicating the range (-2, 3) has length of 5", 5,
       exampleRange4.getLength(), .000000001d); // expected: length is 5 (3 - (-2))
    }

    @After
    public void tearDown() throws Exception { // teardown
    }
}